import { Component } from '@angular/core';

@Component({
  selector: 'app-view-playground',
  templateUrl: './view-playground.component.html',
  styleUrls: ['./view-playground.component.scss']
})
export class ViewPlaygroundComponent {

}
