export class Player {
    id :any;
    name = '';
    contact = '';
    address = '';
    email = '';
    type = '';
    country = '';
    nationlity='';
}
