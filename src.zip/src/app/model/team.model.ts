export class Team {
    id: any;
    name = '';
    type = '';
    bowlers = '';
    batsmans = '';
    allrounders = '';
}
