export class User {
    id :any;
    name = '';
    category = '';
    amount = '';
    date = '';
}
