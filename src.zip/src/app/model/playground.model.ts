export class PlayGround {
    id: any;
    name = '';
    city = '';
    country = '';
    longtude = '';
    latitude = '';


}
