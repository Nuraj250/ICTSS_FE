export class Ground {
    id :any;
    name = '';
    category = '';
    amount = '';
    date = '';
}
