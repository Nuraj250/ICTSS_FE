export const environment = {
  baseUrl: 'http://localhost:4200/',
  production: true
};
